<?php
declare(strict_types=1);
session_start();

$DB_HOST = getenv('LF_DB_HOST') ?: '127.0.0.1';
$DB_NAME = getenv('LF_DB_NAME') ?: 'lost_found';
$DB_USER = getenv('LF_DB_USER') ?: 'root';
$DB_PASS = getenv('LF_DB_PASS') ?: '';

$pdo = null;
$dbError = null;
try {
    $pdo = new PDO(
        "mysql:host={$DB_HOST};dbname={$DB_NAME};charset=utf8mb4",
        $DB_USER,
        $DB_PASS,
        [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]
    );
} catch (PDOException $e) {
    $dbError = $e->getMessage();
}
function db(): PDO {
    global $pdo, $dbError, $DB_NAME;
    if (!$pdo) {
        throw new RuntimeException('MySQL connection failed for database "'.$DB_NAME.'". Make sure MySQL is running in XAMPP and import SQL/lost_and_found.sql in phpMyAdmin. '.($dbError ?: 'Unknown database error.'));
    }
    return $pdo;
}
function e($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function redirect_to(string $page, string $msg=''): never {
    $url = $page . '.php';
    if ($msg !== '') $url .= '?msg='.urlencode($msg);
    header("Location: $url"); exit;
}
function current_user_id(): ?int { return isset($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : null; }
function require_login(): int { $id=current_user_id(); if(!$id) redirect_to('login','Please log in first.'); return $id; }
?>
