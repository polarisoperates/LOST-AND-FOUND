<?php require_once __DIR__."/includes/db.php"; ?>
<!doctype html>
<html lang="en"><head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Lost &amp; Found Community Portal</title>
<script src="https://cdn.tailwindcss.com/3.4.17"></script>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700;800&amp;display=swap" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/lucide@0.577.0/dist/umd/lucide.min.js"></script>
<link rel="stylesheet" href="../CSS/style.css">
</head><body style="background:rgb(255,250,240);"><div class="site-shell">
<header class="nav-wrap">
    <nav class="nav-inner" aria-label="Primary navigation">
     <button type="button" class="brand" onclick="location.href='index.php'" aria-label="Go to Lost and Found home"> <span class="paw">♣</span><span>Lost <span style="color:#f1ae45">&amp;</span> Found<small>Together We Can Find ♡</small></span> </button>
     <div class="nav-links" id="navLinks">
      <button data-template-id="nav-home" class="nav-link canva-link" type="button" onclick="location.href='index.php'" style="color: rgb(21, 57, 91); font-weight: 600;"><i data-lucide="house" width="14"></i><span data-template-id="nav-home-label" class="canva-text" style="color: rgb(21, 57, 91); font-weight: 600; font-style: normal; font-size: 16px;">Home</span></button> <button data-template-id="nav-report-lost" class="nav-link canva-link" type="button" onclick="location.href='report-lost.php'" style="color: rgb(21, 57, 91); font-weight: 600;"><i data-lucide="circle-alert" width="14"></i><span data-template-id="nav-report-lost-label" class="canva-text" style="color: rgb(21, 57, 91); font-weight: 600; font-style: normal; font-size: 16px;">Report Lost</span></button> <button data-template-id="nav-report-found" class="nav-link canva-link" type="button" onclick="location.href='report-found.php'" style="color: rgb(21, 57, 91); font-weight: 600;"><i data-lucide="gift" width="14"></i><span data-template-id="nav-report-found-label" class="canva-text" style="color: rgb(21, 57, 91); font-weight: 600; font-style: normal; font-size: 16px;">Report Found</span></button> <button data-template-id="nav-search" class="nav-link canva-link" type="button" onclick="location.href='search.php'" style="color: rgb(21, 57, 91); font-weight: 600;"><i data-lucide="search" width="14"></i><span data-template-id="nav-search-label" class="canva-text" style="color: rgb(21, 57, 91); font-weight: 600; font-style: normal; font-size: 16px;">Search</span></button>
     </div>
     <div class="nav-actions" id="guestActions">
      <button data-template-id="header-login" class="btn-soft canva-button" type="button" onclick="location.href='login.php'" style="background: rgb(255, 255, 255); color: rgb(40, 123, 173); font-weight: 700; font-style: normal; font-size: 16px;">Login</button> <button data-template-id="header-register" class="btn-main canva-button" type="button" onclick="location.href='register.php'" style="background: rgb(54, 143, 208); color: rgb(255, 255, 255); font-weight: 700; font-style: normal; font-size: 16px;">Register</button>
     </div>
     <div class="nav-actions account-menu" id="userActions" style="display:none">
      <button type="button" class="icon-btn" onclick="toggleNotifications()" aria-label="Notifications" aria-expanded="false" aria-controls="notificationPanel"><i data-lucide="bell" width="18"></i><span id="noticeCount" class="badge rounded-pill text-bg-danger">2</span></button>
      <div class="drop notification-panel" id="notificationPanel" role="region" aria-label="Notifications">
       <div class="notification-head">
        <strong>Notifications</strong><button type="button" class="tiny-btn" onclick="markAllNotificationsRead()">Mark all as read</button>
       </div>
       <div id="notificationList"></div>
      </div><button type="button" class="icon-btn" onclick="toggleDrop()" aria-label="Open account menu"><img data-template-id="nav-avatar" class="avatar-mini canva-image" loading="lazy" src="https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&amp;cs=tinysrgb&amp;w=400" alt="Portrait of a joyful brunette woman with a vibrant smile indoors, capturing happiness and positivity."><span id="navUserName">Your Account</span><i data-lucide="chevron-down" width="15"></i></button>
      <div class="drop" id="accountDrop">
       <button type="button" onclick="location.href='account.php';toggleDrop()">My Account</button> <button type="button" onclick="location.href='settings.php';toggleDrop()">Settings</button> <button type="button" onclick="logout()">Log out</button>
      </div>
     </div><button type="button" class="icon-btn menu-toggle" onclick="toggleMobile()" aria-label="Toggle navigation"><i data-lucide="menu"></i></button>
    </nav>
   </header><main><section id="search" class="view active">
     <div class="search-band">
      <div class="filter-box">
       <h1 data-template-id="search-title" class="canva-text" style="color: rgb(21, 57, 91); font-weight: 800; font-style: normal; font-size: 32px;">Search for Lost or Found Items</h1>
       <p data-template-id="search-subtitle" class="text-center form-note canva-text" style="color: rgb(66, 102, 125); font-weight: 400; font-style: normal; font-size: 16px;">Find what matters… maybe it’s just a click away! ♡</p>
       <form class="search-filters" onsubmit="runSearch(event)"><input id="searchKeyword" class="form-control keyword canva-input" type="search" data-template-id="search-keyword-input" placeholder="Search by item name, mobile, bag, wallet or ID card" style="font-weight: 400; font-style: normal; font-size: 16px;"><select id="searchCategory" class="form-select canva-dropdown"><option value="">All Categories</option><option>Mobiles</option><option>Bags</option><option>ID Cards</option><option>Accessories</option><option>Others</option></select><input id="searchLocation" class="form-control canva-input" type="text" data-template-id="search-location-input" placeholder="Location" style="font-weight: 400; font-style: normal; font-size: 16px;"><input id="searchDate" class="form-control canva-input" type="date"><button data-template-id="search-submit" class="btn-main canva-button" type="submit" style="background: rgb(54, 143, 208); color: rgb(255, 255, 255); font-weight: 700; font-style: normal; font-size: 16px;">Search</button>
       </form>
       <div class="chip-row justify-content-center"><button data-template-id="search-chip-mobiles" class="chip canva-tag" type="button" onclick="quickCategory('Mobiles')" style="background: rgb(255, 255, 255); color: rgb(21, 57, 91); font-weight: 700; font-style: normal; font-size: 16px;">📱 Mobiles</button><button data-template-id="search-chip-bags" class="chip canva-tag" type="button" onclick="quickCategory('Bags')" style="background: rgb(255, 255, 255); color: rgb(21, 57, 91); font-weight: 700; font-style: normal; font-size: 16px;">🎒 Bags</button><button data-template-id="search-chip-id" class="chip canva-tag" type="button" onclick="quickCategory('ID Cards')" style="background: rgb(255, 255, 255); color: rgb(21, 57, 91); font-weight: 700; font-style: normal; font-size: 16px;">🪪 ID Cards</button><button data-template-id="search-chip-accessories" class="chip canva-tag" type="button" onclick="quickCategory('Accessories')" style="background: rgb(255, 255, 255); color: rgb(21, 57, 91); font-weight: 700; font-style: normal; font-size: 16px;">🔑 Accessories</button><button data-template-id="search-chip-others" class="chip canva-tag" type="button" onclick="quickCategory('Others')" style="background: rgb(255, 255, 255); color: rgb(21, 57, 91); font-weight: 700; font-style: normal; font-size: 16px;">••• Others</button>
       </div>
      </div>
     </div>
     <div class="page-width">
      <div class="section-head">
       <h2 data-template-id="search-results-heading" class="canva-text" style="color: rgb(21, 57, 91); font-weight: 800; font-style: normal; font-size: 24px;">♣ Search Results</h2><select id="sortResults" class="form-select" style="width:auto;font-size:12px" onchange="renderSearch()"><option value="newest">Newest first</option><option value="oldest">Oldest first</option><option value="lost">Lost first</option><option value="found">Found first</option></select>
      </div>
      <div id="searchResults" class="listing-grid"></div>
     </div>
    </section></main><footer data-template-id="footer" class="footer canva-footer" style="background: rgb(217, 242, 253); color: rgb(66, 110, 135);"><strong>♣ Lost &amp; Found</strong> · Together We Can Find ♡
  </footer><div id="detailModal" class="detail-modal" role="dialog" aria-modal="true" aria-labelledby="detailTitle">
<div class="detail-card"><button class="close-btn" type="button" onclick="closeDetail()" aria-label="Close item details"><i data-lucide="x"></i></button>
<div id="detailVisual" class="listing-visual"></div><span id="detailBadge" class="badge-status"></span>
<h2 id="detailTitle" class="mt-3" style="font-size:23px;font-weight:800"></h2><p id="detailMeta" class="form-note"></p><p id="detailDescription"></p>
<div class="form-actions"><button id="detailSave" class="btn-soft" type="button">♡ Save item</button></div>
<div class="contact-admin-box" role="note"><strong>Found something?</strong><span>Contact the administrator directly.</span><span>Instagram: <strong>@handle</strong></span><span>Office: <strong>Astron Chowk</strong></span></div></div></div>
<div id="toast" class="toast" role="status"></div>
<script src="../JS/script.js"></script></div></body></html>