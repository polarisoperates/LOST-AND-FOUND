<?php require_once __DIR__."/includes/db.php"; ?>
<!doctype html>
<html lang="en"><head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Lost &amp; Found Community Portal</title>
<script src="https://cdn.tailwindcss.com/3.4.17"></script>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700;800&amp;display=swap" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/lucide@0.577.0/dist/umd/lucide.min.js"></script>
<link rel="stylesheet" href="../CSS/style.css">
</head><body style="background:rgb(255,250,240);"><div class="site-shell">
<header class="nav-wrap">
    <nav class="nav-inner" aria-label="Primary navigation">
     <button type="button" class="brand" onclick="location.href='index.php'" aria-label="Go to Lost and Found home"> <span class="paw">♣</span><span>Lost <span style="color:#f1ae45">&amp;</span> Found<small>Together We Can Find ♡</small></span> </button>
     <div class="nav-links" id="navLinks">
      <button data-template-id="nav-home" class="nav-link canva-link" type="button" onclick="location.href='index.php'" style="color: rgb(21, 57, 91); font-weight: 600;"><i data-lucide="house" width="14"></i><span data-template-id="nav-home-label" class="canva-text" style="color: rgb(21, 57, 91); font-weight: 600; font-style: normal; font-size: 16px;">Home</span></button> <button data-template-id="nav-report-lost" class="nav-link canva-link" type="button" onclick="location.href='report-lost.php'" style="color: rgb(21, 57, 91); font-weight: 600;"><i data-lucide="circle-alert" width="14"></i><span data-template-id="nav-report-lost-label" class="canva-text" style="color: rgb(21, 57, 91); font-weight: 600; font-style: normal; font-size: 16px;">Report Lost</span></button> <button data-template-id="nav-report-found" class="nav-link canva-link" type="button" onclick="location.href='report-found.php'" style="color: rgb(21, 57, 91); font-weight: 600;"><i data-lucide="gift" width="14"></i><span data-template-id="nav-report-found-label" class="canva-text" style="color: rgb(21, 57, 91); font-weight: 600; font-style: normal; font-size: 16px;">Report Found</span></button> <button data-template-id="nav-search" class="nav-link canva-link" type="button" onclick="location.href='search.php'" style="color: rgb(21, 57, 91); font-weight: 600;"><i data-lucide="search" width="14"></i><span data-template-id="nav-search-label" class="canva-text" style="color: rgb(21, 57, 91); font-weight: 600; font-style: normal; font-size: 16px;">Search</span></button>
     </div>
     <div class="nav-actions" id="guestActions">
      <button data-template-id="header-login" class="btn-soft canva-button" type="button" onclick="location.href='login.php'" style="background: rgb(255, 255, 255); color: rgb(40, 123, 173); font-weight: 700; font-style: normal; font-size: 16px;">Login</button> <button data-template-id="header-register" class="btn-main canva-button" type="button" onclick="location.href='register.php'" style="background: rgb(54, 143, 208); color: rgb(255, 255, 255); font-weight: 700; font-style: normal; font-size: 16px;">Register</button>
     </div>
     <div class="nav-actions account-menu" id="userActions" style="display:none">
      <button type="button" class="icon-btn" onclick="toggleNotifications()" aria-label="Notifications" aria-expanded="false" aria-controls="notificationPanel"><i data-lucide="bell" width="18"></i><span id="noticeCount" class="badge rounded-pill text-bg-danger">2</span></button>
      <div class="drop notification-panel" id="notificationPanel" role="region" aria-label="Notifications">
       <div class="notification-head">
        <strong>Notifications</strong><button type="button" class="tiny-btn" onclick="markAllNotificationsRead()">Mark all as read</button>
       </div>
       <div id="notificationList"></div>
      </div><button type="button" class="icon-btn" onclick="toggleDrop()" aria-label="Open account menu"><img data-template-id="nav-avatar" class="avatar-mini canva-image" loading="lazy" src="https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&amp;cs=tinysrgb&amp;w=400" alt="Portrait of a joyful brunette woman with a vibrant smile indoors, capturing happiness and positivity."><span id="navUserName">Your Account</span><i data-lucide="chevron-down" width="15"></i></button>
      <div class="drop" id="accountDrop">
       <button type="button" onclick="location.href='account.php';toggleDrop()">My Account</button> <button type="button" onclick="location.href='settings.php';toggleDrop()">Settings</button> <button type="button" onclick="logout()">Log out</button>
      </div>
     </div><button type="button" class="icon-btn menu-toggle" onclick="toggleMobile()" aria-label="Toggle navigation"><i data-lucide="menu"></i></button>
    </nav>
   </header><main><section id="login" class="view active">
     <div class="auth-layout">
      <div class="auth-art">
       <div class="auth-art-inner">
        <div data-template-id="login-art-kicker" class="eyebrow canva-text" style="color: rgb(44, 152, 204); font-weight: 800; font-style: normal; font-size: 16px;">Good things are out there</div>
        <h1 data-template-id="login-art-title" class="canva-text" style="color: rgb(21, 57, 91); font-weight: 800; font-style: normal; font-size: 32px;">Together, we can find what matters.</h1>
        <div class="auth-pets">
         🐶🐱
        </div>
        <div data-template-id="login-art-board" class="auth-sign canva-banner" style="background: rgb(219, 166, 107); color: rgb(80, 55, 31); font-weight: 800; font-style: normal; font-size: 16px;">Lost &amp; Found
♡</div>
       </div>
      </div>
      <div class="auth-form-side">
       <form class="form-card" onsubmit="login(event)" novalidate="">
        <h1 data-template-id="login-title" class="canva-text" style="color: rgb(21, 57, 91); font-weight: 800; font-style: normal; font-size: 32px;">♣ Welcome Back!</h1>
        <p data-template-id="login-subtitle" class="form-note canva-text" style="color: rgb(113, 135, 153); font-weight: 400; font-style: normal; font-size: 16px;">Log in to your account ♡</p>
        <div id="loginSuccess" class="success-msg" role="status"></div>
        <div class="field"><label data-template-id="login-email-label" class="canva-text" for="loginEmail" style="color: rgb(35, 67, 93); font-weight: 700; font-style: normal; font-size: 16px;">Email or Username</label>
         <div class="input-wrap"><i data-lucide="mail"></i><input id="loginEmail" class="form-control canva-input" type="email" autocomplete="email">
         </div>
         <div id="loginEmailError" class="error"></div>
        </div>
        <div class="field"><label data-template-id="login-password-label" class="canva-text" for="loginPassword" style="color: rgb(35, 67, 93); font-weight: 700; font-style: normal; font-size: 16px;">Password</label>
         <div class="input-wrap"><i data-lucide="lock"></i><input id="loginPassword" class="form-control canva-input" type="password" autocomplete="current-password"><button class="password-toggle" type="button" onclick="togglePassword('loginPassword')" aria-label="Show or hide password"><i data-lucide="eye" width="16"></i></button>
         </div>
         <div id="loginPasswordError" class="error"></div>
        </div>
        <div class="form-row-line"><label><input id="rememberMe" type="checkbox"> <span data-template-id="remember-label" class="canva-text" style="color: rgb(66, 102, 125); font-weight: 400; font-style: normal; font-size: 16px;">Remember me</span></label><button data-template-id="forgot-button" class="text-link canva-link" type="button" onclick="forgotPassword()" style="color: rgb(40, 126, 173); font-weight: 700; font-style: normal; font-size: 16px;">Forgot password?</button>
        </div><button data-template-id="login-submit" class="btn-main canva-button w-100 mt-3" type="submit" style="background: rgb(54, 143, 208); color: rgb(255, 255, 255); font-weight: 700; font-style: normal; font-size: 16px;">Login →</button>
        
        <p class="form-note text-center mt-3 mb-0"><span data-template-id="login-register-prompt" class="canva-text" style="color: rgb(113, 135, 153); font-weight: 400; font-style: normal; font-size: 16px;">Don’t have an account?</span> <button data-template-id="login-register-link" class="text-link canva-link" type="button" onclick="go('register')" style="color: rgb(40, 126, 173); font-weight: 700; font-style: normal; font-size: 16px;">Register →</button></p>
       </form>
      </div>
     </div>
    </section></main><footer data-template-id="footer" class="footer canva-footer" style="background: rgb(217, 242, 253); color: rgb(66, 110, 135);"><strong>♣ Lost &amp; Found</strong> · Together We Can Find ♡
  </footer><div id="detailModal" class="detail-modal" role="dialog" aria-modal="true" aria-labelledby="detailTitle">
<div class="detail-card"><button class="close-btn" type="button" onclick="closeDetail()" aria-label="Close item details"><i data-lucide="x"></i></button>
<div id="detailVisual" class="listing-visual"></div><span id="detailBadge" class="badge-status"></span>
<h2 id="detailTitle" class="mt-3" style="font-size:23px;font-weight:800"></h2><p id="detailMeta" class="form-note"></p><p id="detailDescription"></p>
<div class="form-actions"><button id="detailSave" class="btn-soft" type="button">♡ Save item</button></div>
<div class="contact-admin-box" role="note"><strong>Found something?</strong><span>Contact the administrator directly.</span><span>Instagram: <strong>@handle</strong></span><span>Office: <strong>Astron Chowk</strong></span></div></div></div>
<div id="toast" class="toast" role="status"></div>
<script src="../JS/script.js"></script></div></body></html>