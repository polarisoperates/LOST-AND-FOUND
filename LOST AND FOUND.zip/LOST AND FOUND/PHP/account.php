<?php require_once __DIR__."/includes/db.php"; ?>
<!doctype html>
<html lang="en"><head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Lost &amp; Found Community Portal</title>
<script src="https://cdn.tailwindcss.com/3.4.17"></script>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700;800&amp;display=swap" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/lucide@0.577.0/dist/umd/lucide.min.js"></script>
<link rel="stylesheet" href="../CSS/style.css">
</head><body style="background:rgb(255,250,240);"><div class="site-shell">
<header class="nav-wrap">
    <nav class="nav-inner" aria-label="Primary navigation">
     <button type="button" class="brand" onclick="location.href='index.php'" aria-label="Go to Lost and Found home"> <span class="paw">♣</span><span>Lost <span style="color:#f1ae45">&amp;</span> Found<small>Together We Can Find ♡</small></span> </button>
     <div class="nav-links" id="navLinks">
      <button data-template-id="nav-home" class="nav-link canva-link" type="button" onclick="location.href='index.php'" style="color: rgb(21, 57, 91); font-weight: 600;"><i data-lucide="house" width="14"></i><span data-template-id="nav-home-label" class="canva-text" style="color: rgb(21, 57, 91); font-weight: 600; font-style: normal; font-size: 16px;">Home</span></button> <button data-template-id="nav-report-lost" class="nav-link canva-link" type="button" onclick="location.href='report-lost.php'" style="color: rgb(21, 57, 91); font-weight: 600;"><i data-lucide="circle-alert" width="14"></i><span data-template-id="nav-report-lost-label" class="canva-text" style="color: rgb(21, 57, 91); font-weight: 600; font-style: normal; font-size: 16px;">Report Lost</span></button> <button data-template-id="nav-report-found" class="nav-link canva-link" type="button" onclick="location.href='report-found.php'" style="color: rgb(21, 57, 91); font-weight: 600;"><i data-lucide="gift" width="14"></i><span data-template-id="nav-report-found-label" class="canva-text" style="color: rgb(21, 57, 91); font-weight: 600; font-style: normal; font-size: 16px;">Report Found</span></button> <button data-template-id="nav-search" class="nav-link canva-link" type="button" onclick="location.href='search.php'" style="color: rgb(21, 57, 91); font-weight: 600;"><i data-lucide="search" width="14"></i><span data-template-id="nav-search-label" class="canva-text" style="color: rgb(21, 57, 91); font-weight: 600; font-style: normal; font-size: 16px;">Search</span></button>
     </div>
     <div class="nav-actions" id="guestActions">
      <button data-template-id="header-login" class="btn-soft canva-button" type="button" onclick="location.href='login.php'" style="background: rgb(255, 255, 255); color: rgb(40, 123, 173); font-weight: 700; font-style: normal; font-size: 16px;">Login</button> <button data-template-id="header-register" class="btn-main canva-button" type="button" onclick="location.href='register.php'" style="background: rgb(54, 143, 208); color: rgb(255, 255, 255); font-weight: 700; font-style: normal; font-size: 16px;">Register</button>
     </div>
     <div class="nav-actions account-menu" id="userActions" style="display:none">
      <button type="button" class="icon-btn" onclick="toggleNotifications()" aria-label="Notifications" aria-expanded="false" aria-controls="notificationPanel"><i data-lucide="bell" width="18"></i><span id="noticeCount" class="badge rounded-pill text-bg-danger">2</span></button>
      <div class="drop notification-panel" id="notificationPanel" role="region" aria-label="Notifications">
       <div class="notification-head">
        <strong>Notifications</strong><button type="button" class="tiny-btn" onclick="markAllNotificationsRead()">Mark all as read</button>
       </div>
       <div id="notificationList"></div>
      </div><button type="button" class="icon-btn" onclick="toggleDrop()" aria-label="Open account menu"><img data-template-id="nav-avatar" class="avatar-mini canva-image" loading="lazy" src="https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&amp;cs=tinysrgb&amp;w=400" alt="Portrait of a joyful brunette woman with a vibrant smile indoors, capturing happiness and positivity."><span id="navUserName">Your Account</span><i data-lucide="chevron-down" width="15"></i></button>
      <div class="drop" id="accountDrop">
       <button type="button" onclick="location.href='account.php';toggleDrop()">My Account</button> <button type="button" onclick="location.href='settings.php';toggleDrop()">Settings</button> <button type="button" onclick="logout()">Log out</button>
      </div>
     </div><button type="button" class="icon-btn menu-toggle" onclick="toggleMobile()" aria-label="Toggle navigation"><i data-lucide="menu"></i></button>
    </nav>
   </header><main><section id="account" class="view active">
     <div class="page-width">
      <div class="content-layout">
       <aside class="sidebar" aria-label="Account navigation" id="accountSidebar"></aside>
       <div class="account-grid">
        <div>
         <div class="dashboard-hero">
          <div>
           <div data-template-id="account-kicker" class="eyebrow canva-text" style="color: rgb(44, 152, 204); font-weight: 800; font-style: normal; font-size: 16px;">Kindness can make a big difference. ♡</div>
           <h1 id="accountGreeting">Hi, there!</h1>
           <p data-template-id="account-copy" class="mb-0 canva-text" style="color: rgb(66, 102, 125); font-weight: 400; font-style: normal; font-size: 16px;">Welcome back to your little corner of kindness.</p>
          </div>
          <div class="dashboard-pets" aria-hidden="true">
           🐶🐱
          </div>
         </div>
         <div class="action-grid mt-3"><button data-template-id="account-action-lost" class="action-card lost-card canva-card" type="button" onclick="go('report-lost')" style="background: rgb(232, 246, 255);"><i data-lucide="search"></i><h3>Report Lost Item</h3><p>Help someone find it.</p></button><button data-template-id="account-action-found" class="action-card found-card canva-card" type="button" onclick="go('report-found')" style="background: rgb(255, 234, 240);"><i data-lucide="heart"></i><h3>Report Found Item</h3><p>Make a happy reunion.</p></button><button data-template-id="account-action-reports" class="action-card search-card canva-card" type="button" onclick="go('reports')" style="background: rgb(240, 236, 255);"><i data-lucide="clipboard-list"></i><h3>My Reports</h3><p>View your reports.</p></button>
         </div>
         <div class="section-head">
          <h2 data-template-id="account-recent-heading" class="canva-text" style="color: rgb(21, 57, 91); font-weight: 800; font-style: normal; font-size: 24px;">♣ Recent Items</h2><button data-template-id="account-view-all" class="text-link canva-link" type="button" onclick="go('reports')" style="color: rgb(40, 126, 173); font-weight: 700; font-style: normal; font-size: 16px;">View All →</button>
         </div>
         <div id="accountRecent" class="report-list"></div>
        </div>
        <aside data-template-id="profile-panel" class="profile-panel canva-panel" style="background: rgb(247, 251, 255);"><img data-template-id="profile-avatar" class="canva-image" loading="lazy" src="https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&amp;cs=tinysrgb&amp;w=400" alt="Portrait of a joyful brunette woman with a vibrant smile indoors, capturing happiness and positivity.">
         <h3 id="profileName">Your Name</h3>
         <p id="profileEmail">your@email.com</p><button data-template-id="edit-profile-action" class="btn-soft canva-button" type="button" onclick="go('edit-profile')" style="background: rgb(255, 255, 255); color: rgb(40, 123, 173); font-weight: 700; font-style: normal; font-size: 16px;">Edit Profile →</button>
        </aside>
       </div>
      </div>
     </div>
    </section></main><footer data-template-id="footer" class="footer canva-footer" style="background: rgb(217, 242, 253); color: rgb(66, 110, 135);"><strong>♣ Lost &amp; Found</strong> · Together We Can Find ♡
  </footer><div id="detailModal" class="detail-modal" role="dialog" aria-modal="true" aria-labelledby="detailTitle">
<div class="detail-card"><button class="close-btn" type="button" onclick="closeDetail()" aria-label="Close item details"><i data-lucide="x"></i></button>
<div id="detailVisual" class="listing-visual"></div><span id="detailBadge" class="badge-status"></span>
<h2 id="detailTitle" class="mt-3" style="font-size:23px;font-weight:800"></h2><p id="detailMeta" class="form-note"></p><p id="detailDescription"></p>
<div class="form-actions"><button id="detailSave" class="btn-soft" type="button">♡ Save item</button></div>
<div class="contact-admin-box" role="note"><strong>Found something?</strong><span>Contact the administrator directly.</span><span>Instagram: <strong>@handle</strong></span><span>Office: <strong>Astron Chowk</strong></span></div></div></div>
<div id="toast" class="toast" role="status"></div>
<script src="../JS/script.js"></script></div></body></html>