<?php
require_once __DIR__.'/../includes/db.php';
header('Content-Type: application/json');

try {
    $id = require_login();
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');

    if (strlen($name) < 2 || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        throw new Exception('Add a valid name and email.');
    }

    $avatarPath = null;
    if (isset($_FILES['avatar']) && $_FILES['avatar']['error'] !== UPLOAD_ERR_NO_FILE) {
        if ($_FILES['avatar']['error'] !== UPLOAD_ERR_OK || $_FILES['avatar']['size'] > 3 * 1024 * 1024) {
            throw new Exception('Profile picture must be 3 MB or smaller.');
        }

        $finfo = new finfo(FILEINFO_MIME_TYPE);
        $mime = $finfo->file($_FILES['avatar']['tmp_name']);
        $allowed = [
            'image/jpeg' => 'jpg',
            'image/png' => 'png',
            'image/webp' => 'webp'
        ];
        if (!isset($allowed[$mime])) {
            throw new Exception('Profile picture must be JPG, PNG or WebP.');
        }

        $uploadDir = dirname(__DIR__, 2) . '/uploads';
        if (!is_dir($uploadDir) && !mkdir($uploadDir, 0755, true)) {
            throw new Exception('Could not create the uploads folder.');
        }

        $fileName = 'avatar_' . $id . '_' . bin2hex(random_bytes(8)) . '.' . $allowed[$mime];
        $destination = $uploadDir . '/' . $fileName;
        if (!move_uploaded_file($_FILES['avatar']['tmp_name'], $destination)) {
            throw new Exception('Could not save the profile picture.');
        }
        $avatarPath = 'uploads/' . $fileName;
    }

    if ($avatarPath !== null) {
        $st = db()->prepare("UPDATE users SET name=?, email=?, phone=?, avatar_path=? WHERE id=?");
        $st->execute([$name, $email, $phone ?: null, $avatarPath, $id]);
    } else {
        $st = db()->prepare("UPDATE users SET name=?, email=?, phone=? WHERE id=?");
        $st->execute([$name, $email, $phone ?: null, $id]);
    }

    $_SESSION['user_name'] = $name;
    $_SESSION['user_email'] = $email;

    $st = db()->prepare("SELECT id,name,email,phone,avatar_path FROM users WHERE id=?");
    $st->execute([$id]);
    $user = $st->fetch();

    echo json_encode([
        'ok' => true,
        'message' => 'Profile updated successfully.',
        'user' => $user
    ]);
} catch (Throwable $e) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'message' => $e->getMessage()]);
}
