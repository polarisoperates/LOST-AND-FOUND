<?php
require_once __DIR__.'/../includes/db.php';
header('Content-Type: application/json');
$action=$_GET['action'] ?? $_POST['action'] ?? '';
try {
 if ($action==='register') {
   $name=trim($_POST['name']??''); $email=trim($_POST['email']??''); $pass=$_POST['password']??''; $phone=trim($_POST['phone']??'');
   if(strlen($name)<2 || !filter_var($email,FILTER_VALIDATE_EMAIL) || strlen($pass)<6) throw new Exception('Please enter valid registration details.');
   $st=db()->prepare("SELECT id FROM users WHERE email=?"); $st->execute([$email]);
   if($st->fetch()) throw new Exception('An account with this email already exists.');
   $hash=password_hash($pass,PASSWORD_DEFAULT);
   $st=db()->prepare("INSERT INTO users(name,email,password_hash,phone) VALUES(?,?,?,?)"); $st->execute([$name,$email,$hash,$phone?:null]);
   $_SESSION['user_id']=(int)db()->lastInsertId(); $_SESSION['user_name']=$name; $_SESSION['user_email']=$email;
   echo json_encode(['ok'=>true,'message'=>'Account created successfully.']); exit;
 }
 if ($action==='login') {
   $email=trim($_POST['email']??''); $pass=$_POST['password']??'';
   $st=db()->prepare("SELECT id,name,email,password_hash,phone FROM users WHERE email=?"); $st->execute([$email]); $u=$st->fetch();
   if(!$u || !password_verify($pass,$u['password_hash'])) throw new Exception('Invalid email or password.');
   session_regenerate_id(true); $_SESSION['user_id']=(int)$u['id']; $_SESSION['user_name']=$u['name']; $_SESSION['user_email']=$u['email'];
   echo json_encode(['ok'=>true,'user'=>['name'=>$u['name'],'email'=>$u['email'],'phone'=>$u['phone']]]); exit;
 }
 if ($action==='logout') { $_SESSION=[]; session_destroy(); echo json_encode(['ok'=>true]); exit; }
 throw new Exception('Unknown authentication action.');
} catch(Throwable $e){ http_response_code(400); echo json_encode(['ok'=>false,'message'=>$e->getMessage()]); }