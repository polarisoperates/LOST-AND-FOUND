<?php require_once __DIR__.'/../includes/db.php'; header('Content-Type: application/json');
if(!current_user_id()){echo json_encode(['loggedIn'=>false]);exit;}
$st=db()->prepare("SELECT id,name,email,phone,avatar_path FROM users WHERE id=?");$st->execute([current_user_id()]);$u=$st->fetch();
echo json_encode(['loggedIn'=>!!$u,'user'=>$u?:null]);