<?php
require_once __DIR__.'/../includes/db.php';
header('Content-Type: application/json');
try{
 $q=trim($_GET['q']??'');$cat=trim($_GET['category']??'');$loc=trim($_GET['location']??'');$date=trim($_GET['date']??'');$sort=$_GET['sort']??'newest';
 $sql="SELECT i.id,i.user_id owner_id,i.item_name name,i.category,i.location,i.item_date date,i.report_type type,i.description,i.contact_phone,i.contact_email,i.created_at,u.name owner FROM items i JOIN users u ON u.id=i.user_id WHERE 1=1";
 $p=[];
 if($q!==''){ $sql.=" AND (i.item_name LIKE ? OR i.description LIKE ? OR i.location LIKE ?)"; $z="%$q%"; array_push($p,$z,$z,$z); }
 if($cat!==''){ $sql.=" AND i.category=?";$p[]=$cat;} if($loc!==''){ $sql.=" AND i.location LIKE ?";$p[]="%$loc%";} if($date!==''){ $sql.=" AND i.item_date=?";$p[]=$date;}
 if($sort==='oldest') $order='i.item_date ASC';
 elseif($sort==='lost') $order="i.report_type='Lost' DESC, i.item_date DESC";
 elseif($sort==='found') $order="i.report_type='Found' DESC, i.item_date DESC";
 else $order='i.item_date DESC, i.created_at DESC';
 $sql.=" ORDER BY $order LIMIT 100";
 $st=db()->prepare($sql);$st->execute($p);$rows=$st->fetchAll();
 foreach($rows as &$r){$r['emoji']=$r['category']==='Mobiles'?'📱':($r['category']==='Bags'?'🎒':($r['category']==='ID Cards'?'🪪':($r['category']==='Accessories'?'🎧':'📦')));}
 echo json_encode(['ok'=>true,'items'=>$rows]);
}catch(Throwable $e){http_response_code(500);echo json_encode(['ok'=>false,'message'=>$e->getMessage(),'items'=>[]]);}