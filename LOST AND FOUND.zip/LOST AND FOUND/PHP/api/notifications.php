<?php
require_once __DIR__.'/../includes/db.php';
header('Content-Type: application/json');

try {
    $uid=current_user_id();
    if (!$uid) { echo json_encode(['ok'=>true,'notifications'=>[],'unread'=>0]); exit; }

    $action=$_GET['action'] ?? $_POST['action'] ?? 'list';

    if ($action==='mark_all_read') {
        $st=db()->prepare("UPDATE notifications SET read_at=NOW() WHERE user_id=? AND read_at IS NULL");
        $st->execute([$uid]);
        echo json_encode(['ok'=>true,'message'=>'All notifications marked as read.']);
        exit;
    }

    $st=db()->prepare("SELECT id,type,body,read_at,created_at FROM notifications WHERE user_id=? ORDER BY created_at DESC LIMIT 20");
    $st->execute([$uid]);
    $rows=$st->fetchAll();

    $st=db()->prepare("SELECT COUNT(*) FROM notifications WHERE user_id=? AND read_at IS NULL");
    $st->execute([$uid]);
    echo json_encode(['ok'=>true,'notifications'=>$rows,'unread'=>(int)$st->fetchColumn()]);
} catch(Throwable $e) {
    http_response_code(400);
    echo json_encode(['ok'=>false,'message'=>$e->getMessage(),'notifications'=>[],'unread'=>0]);
}
