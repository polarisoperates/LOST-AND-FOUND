<?php
require_once __DIR__.'/../includes/db.php';
header('Content-Type: application/json');

try {
    $uid = current_user_id();
    if (!$uid) throw new Exception('Please log in before submitting a report.');

    $type = ($_POST['type'] ?? '') === 'Found' ? 'Found' : 'Lost';
    $category = trim($_POST['category'] ?? '');
    $itemName = trim($_POST['name'] ?? '');
    $date = $_POST['date'] ?? '';
    $location = trim($_POST['location'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $email = trim($_POST['email'] ?? '');

    if (!$category || strlen($itemName) < 2 || !$date || strlen($location) < 2 || strlen($description) < 8 || strlen($phone) < 7) {
        throw new Exception('Please fill all required fields correctly.');
    }

    $pdo = db();
    $pdo->beginTransaction();
    try {
        $photoPath = null;
        if (isset($_FILES['photo']) && $_FILES['photo']['error'] !== UPLOAD_ERR_NO_FILE) {
            if ($_FILES['photo']['error'] !== UPLOAD_ERR_OK || $_FILES['photo']['size'] > 5 * 1024 * 1024) {
                throw new Exception('Photo must be 5 MB or smaller.');
            }
            $finfo = new finfo(FILEINFO_MIME_TYPE);
            $mime = $finfo->file($_FILES['photo']['tmp_name']);
            $allowed = ['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'];
            if (!isset($allowed[$mime])) throw new Exception('Only JPG, PNG or WebP images are allowed.');

            $uploadDir = dirname(__DIR__, 2) . '/uploads';
            if (!is_dir($uploadDir) && !mkdir($uploadDir, 0755, true)) {
                throw new Exception('Could not create the uploads folder.');
            }
            $fileName = bin2hex(random_bytes(12)) . '.' . $allowed[$mime];
            $destination = $uploadDir . '/' . $fileName;
            if (!move_uploaded_file($_FILES['photo']['tmp_name'], $destination)) {
                throw new Exception('Could not save uploaded photo.');
            }
            $photoPath = 'uploads/' . $fileName;
        }

        $st = $pdo->prepare('INSERT INTO items(user_id,report_type,category,item_name,item_date,location,description,photo_path,contact_phone,contact_email) VALUES(?,?,?,?,?,?,?,?,?,?)');
        $st->execute([$uid,$type,$category,$itemName,$date,$location,$description,$photoPath,$phone,$email !== '' ? $email : null]);
        $itemId = (int)$pdo->lastInsertId();

        $st = $pdo->prepare('INSERT INTO notifications(user_id,type,body) VALUES(?,?,?)');
        $st->execute([$uid,'report','Your '.$type.' report for “'.$itemName.'” was submitted successfully.']);

        $pdo->commit();
        echo json_encode(['ok'=>true,'message'=>'Your '.strtolower($type).' item report was saved to MySQL.','id'=>$itemId]);
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        throw $e;
    }
} catch (Throwable $e) {
    http_response_code(400);
    echo json_encode(['ok'=>false,'message'=>$e->getMessage()]);
}
