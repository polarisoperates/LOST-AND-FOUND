CREATE DATABASE IF NOT EXISTS lost_found CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE lost_found;

CREATE TABLE users (
 id BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
 name VARCHAR(100) NOT NULL,
 email VARCHAR(255) NOT NULL UNIQUE,
 password_hash VARCHAR(255) NOT NULL,
 phone VARCHAR(30) NULL,
 avatar_path VARCHAR(255) NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE items (
 id BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
 user_id BIGINT UNSIGNED NOT NULL,
 report_type ENUM('Lost','Found') NOT NULL,
 category VARCHAR(50) NOT NULL,
 item_name VARCHAR(150) NOT NULL,
 item_date DATE NOT NULL,
 location VARCHAR(180) NOT NULL,
 description TEXT NOT NULL,
 photo_path VARCHAR(255) NULL,
 contact_phone VARCHAR(30) NOT NULL,
 contact_email VARCHAR(255) NULL,
 status ENUM('Open','Resolved','Closed') DEFAULT 'Open',
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE saved_items (
 user_id BIGINT UNSIGNED NOT NULL,
 item_id BIGINT UNSIGNED NOT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY(user_id,item_id),
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
 FOREIGN KEY(item_id) REFERENCES items(id) ON DELETE CASCADE
) ENGINE=InnoDB;


CREATE TABLE notifications (
 id BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
 user_id BIGINT UNSIGNED NOT NULL,
 type VARCHAR(50) NOT NULL,
 body VARCHAR(255) NOT NULL,
 read_at TIMESTAMP NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Sample data only. It is NOT automatically logged in as any of these users.
INSERT INTO users(name,email,password_hash,phone) VALUES
('Khushi','khushi@email.com','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llCz1g8X0m3qJ2Y2j2w5K','+91 98765 43210'),
('Aarav','aarav@example.com','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llCz1g8X0m3qJ2Y2j2w5K','+91 90000 00001'),
('Riya','riya@example.com','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llCz1g8X0m3qJ2Y2j2w5K','+91 90000 00002'),
('Mira','mira@example.com','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llCz1g8X0m3qJ2Y2j2w5K','+91 90000 00003');

INSERT INTO items(user_id,report_type,category,item_name,item_date,location,description,contact_phone,contact_email) VALUES
(2,'Lost','Mobiles','Mobile Phone','2026-09-08','Library','Black phone with a clear cover. Lost near the study tables.','+91 90000 00001','aarav@example.com'),
(1,'Found','Bags','Backpack','2026-09-07','Cafeteria','Blue college backpack with books inside.','+91 98765 43210','khushi@email.com'),
(3,'Lost','ID Cards','Student ID Card','2026-09-06','College Gate','Student identity card found close to the main entrance.','+91 90000 00002','riya@example.com'),
(1,'Found','Accessories','Earbuds','2026-09-05','Classroom 3','White wireless earbuds in their charging case.','+91 98765 43210','khushi@email.com'),
(4,'Lost','Accessories','Wrist Watch','2026-09-04','Main Park','Black analog watch with a leather strap.','+91 90000 00003','mira@example.com');
