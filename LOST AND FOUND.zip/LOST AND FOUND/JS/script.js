const IS_PHP=location.pathname.toLowerCase().includes('/php/');
const EXT=IS_PHP?'.php':'.html';
const API=IS_PHP?'api':'../PHP/api';
function apiErrorMessage(err,statusText=''){ if(location.protocol==='file:') return 'Please open the website through XAMPP (http://localhost/...), not by double-clicking an HTML file.'; return statusText || (err?.message ? 'Server request failed: '+err.message : 'PHP/MySQL request failed.'); }
async function apiJson(url,options={}){ const r=await fetch(url,options); const raw=await r.text(); let d; try{d=JSON.parse(raw)}catch(_){throw new Error(raw.replace(/<[^>]*>/g,' ').replace(/\s+/g,' ').trim() || ('HTTP '+r.status+' '+r.statusText));} if(!r.ok && !d?.message) throw new Error('HTTP '+r.status+' '+r.statusText); return d; }
const state={loggedIn:false,user:{name:'',email:'',phone:'',avatar_path:''},saved:[],items:[],activeDetail:null};

function page(id){return (id==='home'?'index':id)+EXT}
function go(id){location.href=page(id)}
function setActiveNav(){
 const path=location.pathname.toLowerCase().split('/').pop();
 const navMap={
  'index.php':'nav-home','index.html':'nav-home','':'nav-home',
  'report-lost.php':'nav-report-lost','report-lost.html':'nav-report-lost',
  'report-found.php':'nav-report-found','report-found.html':'nav-report-found',
  'search.php':'nav-search','search.html':'nav-search'
 };
 document.querySelectorAll('.nav-link[data-template-id]').forEach(link=>{
  const isActive=link.dataset.templateId===navMap[path];
  link.classList.toggle('active',isActive);
  link.setAttribute('aria-current',isActive?'page':'false');
 });
}
function toggleMobile(){document.getElementById('navLinks')?.classList.toggle('open')}
function toggleDrop(){document.getElementById('accountDrop')?.classList.toggle('show')}
function showToast(msg){const t=document.getElementById('toast');if(!t)return;t.textContent=msg;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),2800)}
function togglePassword(id){const e=document.getElementById(id);if(e)e.type=e.type==='password'?'text':'password'}
function validate(id,condition,message){const e=document.getElementById(id);if(e)e.textContent=condition?'':message;return condition}
function escapeHTML(s=''){return String(s).replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]))}
function formatDate(d){return new Date(d+'T12:00:00').toLocaleDateString('en-IN',{day:'2-digit',month:'short',year:'numeric'})}
function syncAuth(){
 const guest=document.getElementById('guestActions'),user=document.getElementById('userActions');
 if(guest)guest.style.display=state.loggedIn?'none':'flex';
 if(user)user.style.display=state.loggedIn?'flex':'none';
 ['navUserName','profileName','accountGreeting'].forEach(id=>{const e=document.getElementById(id);if(e)e.textContent=id==='accountGreeting'?'Hi, '+(state.user.name||'there')+'!':(state.user.name||'Your Account')});
 const pe=document.getElementById('profileEmail');if(pe)pe.textContent=state.user.email||'';
 const avatar=state.user.avatar_path ? ((IS_PHP?'../':'')+state.user.avatar_path) : 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=400';
 document.querySelectorAll('img[data-template-id="nav-avatar"],img[data-template-id="profile-avatar"]').forEach(img=>img.src=avatar);
}
async function loadMe(){
 try{const d=await apiJson(API+'/me.php');state.loggedIn=!!d.loggedIn;if(d.user)state.user=d.user;syncAuth();fillProfile()}catch(e){syncAuth()}
}
function fillProfile(){
 [['profileNameInput',state.user.name],['profileEmailInput',state.user.email],['profilePhoneInput',state.user.phone||'']].forEach(([id,v])=>{const e=document.getElementById(id);if(e)e.value=v});
 const preview=document.getElementById('profileAvatarPreview');
 if(preview && state.user.avatar_path){preview.src=(IS_PHP?'../':'')+state.user.avatar_path;preview.style.display='block';}
}

async function login(e){
 e.preventDefault();
 const email=document.getElementById('loginEmail').value.trim(),pass=document.getElementById('loginPassword').value;
 const ok=validate('loginEmailError',/^\S+@\S+\.\S+$/.test(email),'Enter a valid email address.')&validate('loginPasswordError',pass.length>=6,'Use at least 6 characters.');if(!ok)return;
 const fd=new FormData();fd.append('action','login');fd.append('email',email);fd.append('password',pass);
 try{const d=await apiJson(API+'/auth.php',{method:'POST',body:fd});if(!d.ok){showToast(d.message);return}
 state.loggedIn=true;state.user=d.user;syncAuth();const s=document.getElementById('loginSuccess');if(s){s.textContent='Welcome back! Taking you to your account…';s.style.display='block'}setTimeout(()=>go('account'),450);
 }catch(err){showToast(apiErrorMessage(err,err?.message||''))}
}
async function register(e){
 e.preventDefault();
 const n=document.getElementById('regName').value.trim(),em=document.getElementById('regEmail').value.trim(),p=document.getElementById('regPassword').value,c=document.getElementById('regConfirm').value;
 const ok=validate('regNameError',n.length>1,'Please enter your name.')&validate('regEmailError',/^\S+@\S+\.\S+$/.test(em),'Enter a valid email address.')&validate('regPasswordError',p.length>=6,'Use at least 6 characters.')&validate('regConfirmError',p===c&&c.length>0,'Passwords must match.')&validate('termsError',document.getElementById('termsCheck')?.checked,'Please accept the terms to continue.');if(!ok)return;
 const fd=new FormData();fd.append('action','register');fd.append('name',n);fd.append('email',em);fd.append('password',p);
 try{const d=await apiJson(API+'/auth.php',{method:'POST',body:fd});if(!d.ok){showToast(d.message);return}state.loggedIn=true;state.user={name:n,email:em,phone:''};syncAuth();const s=document.getElementById('registerSuccess');if(s){s.textContent='Your account has been created!';s.style.display='block'}setTimeout(()=>go('account'),500)}catch(err){showToast(apiErrorMessage(err,err?.message||''))}
}
async function logout(){try{await fetch(API+'/auth.php?action=logout')}catch(e){}state.loggedIn=false;syncAuth();go('home')}
function forgotPassword(){const e=document.getElementById('loginSuccess');if(e){e.textContent='Password reset is not enabled in this local version. Contact the administrator.';e.style.display='block'}}
function googleDemo(){showToast('Google sign-in demo: this project uses local PHP/MySQL login.')}
function reportForm(prefix){
 return `<div class="report-grid"><div class="field"><label for="${prefix}Category">Item Category *</label><select id="${prefix}Category" class="form-select"><option value="">Select category</option><option>Mobiles</option><option>Bags</option><option>ID Cards</option><option>Accessories</option><option>Others</option></select><div class="error" id="${prefix}CategoryError"></div></div>
 <div class="field"><label for="${prefix}Name">Item Name *</label><input id="${prefix}Name" class="form-control" type="text" placeholder="e.g. Mobile Phone"><div class="error" id="${prefix}NameError"></div></div>
 <div class="field"><label for="${prefix}Date">Date *</label><input id="${prefix}Date" class="form-control" type="date"><div class="error" id="${prefix}DateError"></div></div>
 <div class="field"><label for="${prefix}Location">Location *</label><input id="${prefix}Location" class="form-control" type="text" placeholder="e.g. Library, Canteen"><div class="error" id="${prefix}LocationError"></div></div>
 <div class="field full"><label for="${prefix}Description">Item Description *</label><textarea id="${prefix}Description" class="form-control" rows="3" placeholder="Colour, brand, size, unique marks…"></textarea><div class="error" id="${prefix}DescriptionError"></div></div>
 <div class="field"><label for="${prefix}Photo">Upload Photo (Optional)</label><label class="upload-zone" for="${prefix}Photo"><i data-lucide="upload-cloud"></i><br>Click to upload an image<br><small>JPG, PNG or WebP · max 5 MB</small></label><input id="${prefix}Photo" type="file" accept="image/png,image/jpeg,image/webp" hidden onchange="previewFile('${prefix}')"><img class="preview" id="${prefix}Preview"><div class="error" id="${prefix}PhotoError"></div></div>
 <div class="field"><label for="${prefix}Phone">Contact Number *</label><input id="${prefix}Phone" class="form-control" type="tel" placeholder="+91 98765 43210"><div class="error" id="${prefix}PhoneError"></div><label class="mt-2" for="${prefix}Email">Email Address (Optional)</label><input id="${prefix}Email" class="form-control" type="email" placeholder="you@example.com"></div></div>
 <div class="form-actions"><button class="btn-main" type="submit">Submit Report</button><button class="btn-outline" type="reset">Reset</button></div>`
}
function initReportForms(){const l=document.getElementById('lostForm'),f=document.getElementById('foundForm');if(l&&!l.innerHTML)l.innerHTML=reportForm('lost');if(f&&!f.innerHTML)f.innerHTML=reportForm('found');if(window.lucide)lucide.createIcons()}
function previewFile(prefix){const f=document.getElementById(prefix+'Photo')?.files[0],err=document.getElementById(prefix+'PhotoError'),img=document.getElementById(prefix+'Preview');if(!err||!img)return;err.textContent='';if(!f)return;if(!['image/jpeg','image/png','image/webp'].includes(f.type)){err.textContent='Please select a JPG, PNG, or WebP image.';return}if(f.size>5*1024*1024){err.textContent='Photo must be 5 MB or smaller.';return}img.src=URL.createObjectURL(f);img.style.display='block'}
function resetReport(prefix){setTimeout(()=>{const i=document.getElementById(prefix+'Preview');if(i)i.style.display='none';},0)}
async function submitReport(e,type){
 e.preventDefault();if(!state.loggedIn){showToast('Please log in before submitting a report.');go('login');return}
 const p=type==='Lost'?'lost':'found';
 const category=document.getElementById(p+'Category').value,name=document.getElementById(p+'Name').value.trim(),date=document.getElementById(p+'Date').value,location=document.getElementById(p+'Location').value.trim(),description=document.getElementById(p+'Description').value.trim(),phone=document.getElementById(p+'Phone').value.trim(),email=document.getElementById(p+'Email').value.trim();
 const ok=validate(p+'CategoryError',!!category,'Choose a category.')&validate(p+'NameError',name.length>1,'Enter an item name.')&validate(p+'DateError',!!date,'Choose a date.')&validate(p+'LocationError',location.length>1,'Enter a location.')&validate(p+'DescriptionError',description.length>8,'Add a little more detail.')&validate(p+'PhoneError',phone.length>6,'Enter a contact number.');if(!ok)return;
 const fd=new FormData();[['type',type],['category',category],['name',name],['date',date],['location',location],['description',description],['phone',phone],['email',email]].forEach(([k,v])=>fd.append(k,v));const file=document.getElementById(p+'Photo')?.files[0];if(file)fd.append('photo',file);
 try{const d=await apiJson(API+'/report.php',{method:'POST',body:fd});if(!d.ok){showToast(d.message);return}const s=document.getElementById(p+'ReportSuccess');if(s){s.textContent=d.message;s.style.display='block'}e.target.reset();resetReport(p);showToast('Report submitted successfully.');setTimeout(()=>go('reports'),700)}catch(err){showToast(apiErrorMessage(err,err?.message||''))}}
async function loadItems(params={}){
 try{const q=new URLSearchParams(params);const d=await apiJson(API+'/items.php?'+q);state.items=d.items||[];renderLists()}catch(e){state.items=[];renderLists()}
}
function card(item){const id=item.id,saved=state.saved.includes(id);return `<article class="listing-card"><span class="badge-status ${item.type==='Lost'?'lost':'found'}">${item.type}</span><div class="listing-visual">${item.emoji||'📦'}</div><div class="listing-info"><h3>${escapeHTML(item.name)}</h3><p>⌖ ${escapeHTML(item.location)}</p><p>◷ ${formatDate(item.date)}</p><div class="listing-actions"><button class="tiny-btn" onclick="openDetail(${id})">View details →</button><button class="tiny-btn" onclick="toggleSave(${id})">${saved?'♥ Saved':'♡ Save'}</button></div></div></article>`}
function renderLists(){
 const home=document.getElementById('homeListings');
 if(home)home.innerHTML=state.items.slice(0,5).map(card).join('');
 const results=document.getElementById('searchResults');
 if(results)results.innerHTML=state.items.length?state.items.map(card).join(''):`<div class="empty-state" style="grid-column:1/-1">🔎<br><strong>No items match those filters yet.</strong><br>Try a different search or report an item.</div>`;
 const saved=document.getElementById('savedList');
 if(saved)saved.innerHTML=state.items.filter(x=>state.saved.includes(Number(x.id))).map(card).join('')||'<div class="empty-state" style="grid-column:1/-1">♡<br><strong>No saved items yet.</strong></div>';
 const mine=state.items.filter(x=>Number(x.owner_id)===Number(state.user.id));
 const reports=document.getElementById('reportsList');
 if(reports)reports.innerHTML=mine.map(x=>`<div class="row-item" onclick="openDetail(${x.id})" style="cursor:pointer"><div class="row-icon">${x.emoji}</div><div class="row-main"><strong>${escapeHTML(x.name)}</strong><span>${x.type} report · ${escapeHTML(x.location)} · ${formatDate(x.date)}</span></div><span class="badge-status ${x.type==='Lost'?'lost':'found'}" style="position:static">${x.type}</span></div>`).join('')||'<div class="empty-state">No reports yet. Your submitted reports will appear here.</div>';
 const recent=document.getElementById('accountRecent');
 if(recent)recent.innerHTML=mine.slice().sort((a,b)=>new Date(b.created_at||b.date)-new Date(a.created_at||a.date)).slice(0,5).map(x=>`<div class="row-item" onclick="openDetail(${x.id})" style="cursor:pointer"><div class="row-icon">${x.emoji}</div><div class="row-main"><strong>${escapeHTML(x.name)}</strong><span>${x.type} report · ${escapeHTML(x.location)} · ${formatDate(x.date)}</span></div><span class="badge-status ${x.type==='Lost'?'lost':'found'}" style="position:static">${x.type}</span></div>`).join('')||'<div class="empty-state">No recent items yet.</div>';
}
function getSearchParams(){
 return {
  q:document.getElementById('searchKeyword')?.value.trim()||'',
  category:document.getElementById('searchCategory')?.value||'',
  location:document.getElementById('searchLocation')?.value.trim()||'',
  date:document.getElementById('searchDate')?.value||'',
  sort:document.getElementById('sortResults')?.value||'newest'
 };
}
function runSearch(e){e.preventDefault();loadItems(getSearchParams())}
function renderSearch(){
 if(!document.getElementById('searchResults'))return;
 loadItems(getSearchParams());
}
function homeSearch(e){e.preventDefault();const q=document.getElementById('homeSearch').value.trim();go('search');sessionStorage.setItem('lf_search',q)}
function quickCategory(category){sessionStorage.setItem('lf_category',category);go('search')}
function initSearch(){
 const q=sessionStorage.getItem('lf_search')||'',cat=sessionStorage.getItem('lf_category')||'';
 const a=document.getElementById('searchKeyword'),b=document.getElementById('searchCategory'),sort=document.getElementById('sortResults');
 if(a)a.value=q;
 if(b)b.value=cat;
 if(sort)sort.value='newest';
 loadItems({q,category:cat,sort:sort?.value||'newest'});
 sessionStorage.removeItem('lf_search');
 sessionStorage.removeItem('lf_category');
}
function openDetail(id){const x=state.items.find(i=>Number(i.id)===Number(id));if(!x)return;state.activeDetail=id;document.getElementById('detailVisual').textContent=x.emoji||'📦';const b=document.getElementById('detailBadge');b.textContent=x.type;b.className='badge-status '+(x.type==='Lost'?'lost':'found');document.getElementById('detailTitle').textContent=x.name;document.getElementById('detailMeta').textContent=x.category+' · '+x.location+' · '+formatDate(x.date);document.getElementById('detailDescription').textContent=x.description;const btn=document.getElementById('detailSave');btn.textContent=state.saved.includes(id)?'♥ Saved':'♡ Save item';btn.onclick=()=>toggleSave(id);document.getElementById('detailModal').classList.add('show')}
function closeDetail(){document.getElementById('detailModal')?.classList.remove('show')}
function toggleSave(id){id=Number(id);if(!state.loggedIn){showToast('Please log in to save items.');go('login');return}state.saved.includes(id)?state.saved=state.saved.filter(x=>x!==id):state.saved.push(id);showToast(state.saved.includes(id)?'Item saved to your list.':'Item removed from saved items.');renderLists();if(state.activeDetail)openDetail(state.activeDetail)}
function previewAvatar(input){
 const file=input?.files?.[0]; if(!file)return;
 if(file.size>3*1024*1024){showToast('Profile picture must be 3 MB or smaller.');input.value='';return;}
 const preview=document.getElementById('profileAvatarPreview');
 if(preview){preview.src=URL.createObjectURL(file);preview.style.display='block';}
}
async function saveProfile(e){
 e.preventDefault();
 const fd=new FormData();
 fd.append('name',document.getElementById('profileNameInput').value.trim());
 fd.append('email',document.getElementById('profileEmailInput').value.trim());
 fd.append('phone',document.getElementById('profilePhoneInput').value.trim());
 const avatar=document.getElementById('profileAvatarInput')?.files?.[0]; if(avatar)fd.append('avatar',avatar);
 try{
   const d=await apiJson(API+'/profile.php',{method:'POST',body:fd});
   if(!d.ok){showToast(d.message);return}
   if(d.user)state.user=d.user;
   syncAuth(); fillProfile(); showToast(d.message);
 }catch(err){showToast(apiErrorMessage(err,err?.message||''))}
}

async function loadNotifications(){
 try{
   const d=await apiJson(API+'/notifications.php');
   const list=document.getElementById('notificationList'),count=document.getElementById('noticeCount');
   if(count){count.textContent=d.unread||0;count.style.display=(d.unread||0)?'inline-block':'none';}
   if(list){
     const rows=d.notifications||[];
     list.innerHTML=rows.length?rows.map(n=>`<div class="notification-item ${n.read_at?'read':''}"><strong>${escapeHTML(n.type==='report'?'Report update':'Notification')}</strong><span>${escapeHTML(n.body)}</span><small>${escapeHTML(formatDateTime(n.created_at))}</small></div>`).join(''):'<div class="empty-state">No notifications yet.</div>';
   }
 }catch(e){}
}
function formatDateTime(value){const d=new Date(String(value).replace(' ','T'));return isNaN(d)?String(value):d.toLocaleString('en-IN',{day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit'});}
function toggleNotifications(){
 const p=document.getElementById('notificationPanel'); if(!p)return;
 p.classList.toggle('show');
 if(p.classList.contains('show'))loadNotifications();
}
async function markAllNotificationsRead(){
 try{const d=await apiJson(API+'/notifications.php',{method:'POST',body:new URLSearchParams({action:'mark_all_read'})});showToast(d.message||'Notifications marked as read.');loadNotifications();}
 catch(e){showToast(apiErrorMessage(e,e?.message||''))}
}

async function init(){
 setActiveNav(); await loadMe(); initReportForms();
 const p=location.pathname.toLowerCase();
 if(p.endsWith('/index.html')||p.endsWith('/index.php')||p.endsWith('/'))loadItems();
 if(p.includes('search.'))initSearch();
 if(p.includes('reports.')||p.includes('account.')||p.includes('saved.'))loadItems();
 loadNotifications();
 renderLists();
 if(window.lucide)lucide.createIcons();
}
document.addEventListener('DOMContentLoaded',init);
