LOST & FOUND - CLEAN XAMPP PROJECT

MAIN WORKING VERSION
--------------------
The PHP version inside the PHP folder is the main working website. Use it through XAMPP.

FOLDER STRUCTURE
----------------
PHP/        Working PHP pages, API files, and database connection
CSS/        Main stylesheet
JS/         Main JavaScript file
SQL/        MySQL database import file
uploads/    Uploaded item/profile images

The old static HTML copies were removed from this clean version because the PHP website is the working version and the HTML copies were duplicates. Removing them does not affect the PHP website or its MySQL functionality.

XAMPP SETUP
-----------
1. Copy the entire "LOST AND FOUND" folder into:
   C:\xampp\htdocs\

2. Start Apache and MySQL in XAMPP.

3. Open:
   http://localhost/phpmyadmin/

4. Click Import and select:
   LOST AND FOUND\SQL\database.sql

5. Click Go.

6. Open the website in Chrome:
   http://localhost/LOST%20AND%20FOUND/PHP/

DATABASE
--------
Database name: lost_found
Username: root
Password: blank by default in XAMPP

IMPORTANT
---------
- Use the PHP version through XAMPP.
- Do not double-click PHP files from Windows.
- Your existing MySQL database can be kept; you do not need to delete it just to replace the project files.
- The uploads folder is intentionally kept because submitted images are stored there.
